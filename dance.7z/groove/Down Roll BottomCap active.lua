local t = Def.Sprite {
	Texture=NOTESKIN:GetPath( '_Down', 'roll bottomcap active' );
	Frame0000=0;
	Delay0000=0.44;
	Frame0001=1;
	Delay0001=0.03;
	Frame0002=2;
	Delay0002=0.03;
	Frame0003=3;
	Delay0003=0.44;
	Frame0004=2;
	Delay0004=0.03;
	Frame0005=1;
	Delay0005=0.03;
};
return t;