return Def.Sprite {
	Texture=NOTESKIN:GetPath('Up','Roll BottomCap Active');
	InitCommand=cmd(diffuse,color("0.5,0.5,0.5,0.5"));
};