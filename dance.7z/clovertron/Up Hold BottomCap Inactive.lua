return Def.Sprite {
	Texture=NOTESKIN:GetPath('Up','Hold BottomCap Active');
	InitCommand=cmd(diffuse,color("0.5,0.5,0.5,0.5"));
};