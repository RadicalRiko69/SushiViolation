return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_Up', 'tap note' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
