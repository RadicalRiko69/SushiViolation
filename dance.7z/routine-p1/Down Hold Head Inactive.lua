return Def.Sprite {
	Texture=NOTESKIN:GetPath('Down','Hold Head Active');
	InitCommand=cmd(diffuse,color("0.5,0.5,0.5,1"));
};