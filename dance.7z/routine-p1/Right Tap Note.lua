return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_right', 'tap note' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
