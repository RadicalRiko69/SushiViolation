return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_left', 'tap note' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
