return Def.Sprite {
	Texture=NOTESKIN:GetPath('Down','Roll Head Active');
	InitCommand=cmd(diffuse,color("0.5,0.5,0.5,1"));
};